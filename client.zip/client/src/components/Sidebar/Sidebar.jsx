import { NavLink } from 'react-router-dom'
import { Factory, Building2, Store, UserRound, UserCheck, Users, LogOut, X, TrendingUp,  FileText, CreditCard, Package, LayoutDashboard, ShoppingCart, DollarSign, User, BarChart3, Truck, Gift } from 'lucide-react'
import { logout } from '../../lib/auth'
import { getCurrentUserRole } from '../../lib/roles'
import Button from '../ui/Button'

const black = '/lottie/Roshan_black.png'

const linkBase = "flex items-center gap-3 px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg sm:rounded-xl text-sm font-medium transition-all duration-200 group relative"
const active = ({ isActive }) =>
  isActive 
    ? `${linkBase} bg-[#F08344] text-white shadow-lg shadow-[#F08344]/25` 
    : `${linkBase} text-slate-600 hover:bg-slate-50 hover:text-slate-900 hover:shadow-sm`

const MENU_CONFIG = {
 superadmin: [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/manufacturers', label: 'Manufacturers', icon: Factory },
    { to: '/agents', label: 'Agents', icon: UserRound },
    { to: '/companies', label: 'Companies', icon: Building2 },
    { to: '/employees', label: 'Employees', icon: Gift },
    { to: '/products', label: 'Products', icon: Package },
    { to: '/users', label: 'Users', icon: Users },
    { to: '/orders', label: 'Orders', icon: ShoppingCart },
    { to: '/paymentreports', label: 'Payment Reports', icon: CreditCard },
    { to: '/report', label: 'Reports', icon: FileText },
    { to: '/signup-approval', label: 'SignUp Approval', icon: UserCheck },
  ],
  agent: [
    { to: '/agents/dashboard', label: 'Dashboard', icon: TrendingUp },
    { to: '/agents/products', label: 'Products', icon: Package },
    { to: '/agents/orders', label: 'Orders', icon: ShoppingCart },
    { to: '/agents/payment-report', label: 'Payment Report', icon: DollarSign },
    { to: '/agents/profile', label: 'Profile', icon: User },
    { to: '/agents/reports', label: 'Reports', icon: BarChart3 },
  ],
  manufacturer: [
    { to: '/manufacturers/dashboard', label: 'Dashboard', icon: TrendingUp },
    { to: '/manufacturers/products', label: 'Products', icon: Package },
    { to: '/manufacturers/orders', label: 'Customer Orders', icon: ShoppingCart },
    { to: '/manufacturers/employees', label: 'Employees', icon: Gift },
    { to: '/manufacturers/payments', label: 'Payments', icon: DollarSign },
    { to: '/manufacturers/reports', label: 'Reports', icon: BarChart3 },
    { to: '/manufacturers/profile', label: 'Profile', icon: User },
  ],
  truckowner: [
    { to: '/truck owners/dashboard', label: 'Dashboard', icon: Truck },
    { to: '/truck owners/driver-management', label: 'Driver Management', icon: Users },
    { to: '/truck owners/truck-management', label: 'Truck Management', icon: Truck },
    { to: '/truck owners/trips', label: 'Trips', icon: Package },
    { to: '/truck owners/payments', label: 'Payments', icon: DollarSign },
    { to: '/truck owners/profile', label: 'Profile', icon: User },
  ],
  driver: [
    { to: '/drivers', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/drivers/trip-details', label: 'Delivery Trips', icon: Truck },
    { to: '/drivers/earnings', label: 'Earnings', icon: DollarSign },
    { to: '/drivers/profile', label: 'Profile', icon: User },
  ],
}

export default function Sidebar({ isCollapsed, onClose, mobile }) {
  const role = getCurrentUserRole()
  console.log("Sidebar role:", role) // Debug log for role
  
  return (
    <>
      {/* Mobile Overlay */}
      {mobile && (
        <div 
          className="fixed inset-0 bg-black/40 z-40 md:hidden" 
          onClick={onClose}
          aria-hidden="true"
        />
      )}
      
      <aside
        className={`
          ${mobile 
            ? 'fixed inset-y-0 left-0 z-50 w-64 sm:w-72 bg-white border-r border-slate-200 flex flex-col shadow-2xl transform transition-transform duration-300 md:hidden'
            : `h-screen bg-white border-r border-slate-200 sticky top-0 hidden md:flex flex-col transition-all duration-300 shadow-sm ${
                isCollapsed ? 'w-16 lg:w-20' : 'w-64 lg:w-72'
              }`
          }
        `}
      >
        {/* Header */}
        <div
          className={`h-14 sm:h-16 border-b border-slate-200 flex items-center px-3 sm:px-6 bg-gradient-to-r from-slate-50 to-white ${
            isCollapsed && !mobile ? 'justify-center' : 'justify-between'
          }`}>
          <div className={`flex items-center gap-2 sm:gap-3 ${
            isCollapsed && !mobile ? 'justify-center' : ''
          }`}>
           
            {(!isCollapsed || mobile) && (
              <div>
                <img src={black} alt="Roshan Traders" className="h-10 w-35" />
              </div>
            )}
          </div>
          {(mobile || (!isCollapsed && onClose)) && (
            <button
              className="p-1.5 sm:p-2 rounded-lg hover:bg-slate-100 text-slate-500 transition-colors"
              onClick={onClose}
              aria-label="Close sidebar"
            >
              <X className="size-4 sm:size-5" />
            </button>
          )}
        </div>

        {/* Navigation */}
        <nav className={`flex-1 p-3 sm:p-4 space-y-1 sm:space-y-2 overflow-y-auto ${
          isCollapsed && !mobile ? 'flex flex-col items-center' : ''
        }`}>
          
          {(MENU_CONFIG[role] || []).map((item) => {
            const Icon = item.icon
            return (
              <NavLink
                key={item.to}
                to={item.to}
                className={active}
                onClick={mobile ? onClose : undefined}
              >
                <Icon className="size-4 sm:size-5 flex-shrink-0" />
                {(!isCollapsed || mobile) && (
                  <span className="group-hover:translate-x-0.5 transition-transform truncate">
                    {item.label}
                  </span>
                )}
                {(!isCollapsed || mobile) && (
                  <div className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-1.5 h-1.5 bg-current rounded-full"></div>
                  </div>
                )}
              </NavLink>
            )
          })}
        </nav>

        {/* Logout Section */}
        <div className={`p-3 sm:p-4 border-t border-slate-200 bg-slate-50/50 ${
          isCollapsed && !mobile ? 'flex justify-center' : ''
        }`}>
          <Button
            variant="primary"
            className={`w-full flex items-center gap-2 sm:gap-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white border-0 shadow-lg shadow-red-500/25 hover:shadow-red-500/40 transition-all duration-200 font-medium text-sm ${
              isCollapsed && !mobile ? 'justify-center px-2 py-2' : 'px-3 sm:px-4 py-2 sm:py-2.5'
            }`}
            onClick={() => {
              logout();
              window.location.href = "/user/login";
            }}
          >
            <LogOut className="size-4 flex-shrink-0" />
            {(!isCollapsed || mobile) && <span className="truncate">Logout</span>}
          </Button>
        </div>
      </aside>
    </>
  )
}
