export const pudgy = '/lottie/Pudgy Build.lottie';
export const truck1 = '/lottie/Supply Chain and Shipping.lottie'
export const truck2 = '/lottie/Truck.lottie'
export const truck3 = '/lottie/Forklift loading truck.lottie'
export const white = '/lottie/Roshan_white.png'
export const black = '/lottie/Roshan_black.png'
